from sucifa.config import Config
from sucifa.helpers import *

Chakka = "You"
Print(f"????? .....")

"""
Bhag ja madarchod
Kahi aur gand mra
"""
