# Here we control plugins with SQL Mode
