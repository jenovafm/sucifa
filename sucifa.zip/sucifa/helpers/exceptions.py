class CancelProcess(Exception):
    """
    Cancel Process
    """

# hellbot
