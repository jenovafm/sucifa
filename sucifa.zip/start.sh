#!/bin/bash


echo """
<3 Suci FA
"""

python3 -m sucifa
